"use client"

import { AppProvider, useApp } from '@/lib/app-context'
import { SplashScreen } from '@/components/splash-screen'
import { LandingPage } from '@/components/landing-page'
import { SignInPage, SignUpPage } from '@/components/auth-pages'
import { DashboardLayout } from '@/components/dashboard-layout'
import { DashboardHome } from '@/components/dashboard-home'
import { TasksPage } from '@/components/tasks-page'
import { PostTaskPage } from '@/components/post-task-page'
import { MyTasksPage } from '@/components/my-tasks-page'
import { ChatPage } from '@/components/chat-page'
import { LeaderboardPage } from '@/components/leaderboard-page'
import { WalletPage } from '@/components/wallet-page'
import { ProfilePage } from '@/components/profile-page'

function AppContent() {
  const { page } = useApp()

  // Non-dashboard pages
  if (page === 'splash') return <SplashScreen />
  if (page === 'landing') return <LandingPage />
  if (page === 'signin') return <SignInPage />
  if (page === 'signup') return <SignUpPage />

  // Dashboard pages
  const dashboardContent = {
    dashboard: <DashboardHome />,
    tasks: <TasksPage />,
    'post-task': <PostTaskPage />,
    'my-tasks': <MyTasksPage />,
    chat: <ChatPage />,
    leaderboard: <LeaderboardPage />,
    wallet: <WalletPage />,
    profile: <ProfilePage />,
  }

  return (
    <DashboardLayout>
      {dashboardContent[page as keyof typeof dashboardContent] || <DashboardHome />}
    </DashboardLayout>
  )
}

export default function Page() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  )
}
